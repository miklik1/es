/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "MKL25Z4.h"
#include "FreeRTOS.h"
#include "drv_gpio.h"
#include "drv_lcd.h"
#include "dc_motor.h"

static int i = 0;
char buf[16];

void Input( void * pvParameters );
void Reader( void * pvParameters );
void Display( void * pvParameters );
void delay(void);

int main(void)
{
	GPIO_Initialize();
	pinMode(SW1, INPUT_PULLUP);
	pinMode(SW2, INPUT_PULLUP);
	pinMode(SW3, INPUT_PULLUP);
	pinMode(SW4, INPUT_PULLUP);
    LCD_initialize();
    LCD_clear();

    DCMOTOR_Init();
    DCMOTOR_setDirection(0);

    xTaskCreate(Input, /* ukazatel na task */
		"Input", /* jmeno tasku pro ladeni - kernel awareness debugging */
		configMINIMAL_STACK_SIZE, /* velikost zasobniku = task stack size */
		(void*)NULL, /* pripadny parametr pro task = optional task startup argument */
		tskIDLE_PRIORITY + 1, /* priorita tasku, nizsi nez ostatnich */
		(xTaskHandle*)NULL /* pripadne handle na task, pokud ma byt vytvoreno */
    );

    xTaskCreate(Display, /* ukazatel na task */
		"GUI", /* jmeno tasku pro ladeni - kernel awareness debugging */
		configMINIMAL_STACK_SIZE, /* velikost zasobniku = task stack size */
		(void*)NULL, /* pripadny parametr pro task = optional task startup argument */
		tskIDLE_PRIORITY + 1, /* priorita tasku, nizsi nez ostatnich */
		(xTaskHandle*)NULL /* pripadne handle na task, pokud ma byt vytvoreno */
	);

    vTaskStartScheduler(); /* does not return */

	// Sem bychom se nikdy nemeli dostat
	while (1)
		;

	/* Never leave main */
	return 0;
}

void Input( void * pvParameters )
{
	(void) pvParameters;

	for( ;; ) {

		if ( pinRead(SW1) == LOW)
			DCMOTOR_SpinON();

		if ( pinRead(SW2) == LOW)
			DCMOTOR_SpinOFF();

		if ( pinRead(SW3) == LOW ) {
			DCMOTOR_SpinOFF();
			delay();
			DCMOTOR_setDirection(0);
		}

		if ( pinRead(SW4) == LOW) {
			DCMOTOR_SpinOFF();
			delay();
			DCMOTOR_setDirection(1);
		}
	}
}

void Display( void * pvParameters )
{
	(void) pvParameters; /* parameter not used */

	for( ;; ) {
		int rpm = DCMOTOR_GetRpm();
		sprintf(buf, "%d", rpm);
		LCD_clear();
		LCD_puts(buf);
		vTaskDelay(100 / portTICK_RATE_MS);
	}
}

void delay(void) {
	long n = 500000;
	while ( n-- > 0 )
		;
}
////////////////////////////////////////////////////////////////////////////////
// EOF
////////////////////////////////////////////////////////////////////////////////
