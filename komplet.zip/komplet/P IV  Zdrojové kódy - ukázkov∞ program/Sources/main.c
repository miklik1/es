#include "main_asm.h" /* interface to the assembly module */

#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include "math.h"

#include "disp_gb60.h"
#include <stdio.h>
#include "sci_gb60.h"
#include "fm_modul.h"
 

void menu(int i);
void pockej(void);


interrupt void kbi_int(void);  
void (*const obsluha)(void) @0xFFD2 = kbi_int;

/* globalni promenna na vypis menu */
int pol_menu=0;


void main(void) {

  /*--- rc5 promenne ----*/
  char togglebit = 0, databit = 0;
  int kontrola = 0;
  char temptoggle = 2, tempdata = 255;
  /*---------------------*/
  /* programove promenne */
  int i,rezim,aut_rezim,aut_rezim2,zb,zb2,audio,stdby,snc,z,freq,send,mute_L,mute_P,mute_celk,get_freq;               
  int pamet[5];
  char buff[50];
 
  /* init clock generatoru MPC */
  ICG_init();
 
  /* inicializace tlacitek SW1-SW4, nastaveni preruseni na SW1, inicializace A/D prevodniku */
  PTADD=0x00;       
  PTAPE=0xf0;
  
  /* inicializace kbi preruseni na tlacitko SW1 */
  KBI1SC = 0x06;
  KBI1PE = 0x10; 
  
  /* nastaveni D/A prevodniku: D4 pro 10bit  E4 pro 8bit */ 
  ATD1C = 0xD4;
  ATD1PE = 1;
  
  EnableInterrupts; /* enable interrupts */
 
  /* inicializace displeje, a jeho vymazani */
  dinit();          
  dcls();
  
  /* inicializace I2C komunikace */
  Init_I2C();    
  
  /* inicializace RC5 */   
  Init_RC5();

  /* nastaveni inicializacnich hodnot promennych */
  i=0;              
  rezim=0; 
  aut_rezim=0;
  aut_rezim2=0;
  freq=0; 
  stdby=0;
  audio=0;
  snc=0;
  zb=91;
  zb2=7;
  mute_L=mute_P=mute_celk=0;
  send=1;  
    
  /* inicializace prvnothnich hodnot do pameti radii */
  for(z=0;z<5;z++){
  pamet[z]=896;
  }
  z=0;
  
  while(1) {
      /* vypis menu podle aktualni polozky*/
      menu(pol_menu);    
      
      /* kodove reseni jednotlivych polozek menu */
      /* Pol.1 - manualni ladeni */                   
      if(pol_menu==1){
        
        while(PTAD_PTAD5==0){
          ATD1SC = 0;
          while(ATD1SC_CCF!=1) __RESET_WATCHDOG();
          zb=(21*ATD1R/1022)+87;
          sprintf(buff, "%3d.%d",zb,zb2);
          setcursor(2,12);
          dtext(buff);
          send=1;     
        }
        
        while(PTAD_PTAD6==0){
          ATD1SC = 0;
          while(ATD1SC_CCF!=1) __RESET_WATCHDOG();
          zb2=9*ATD1R/1022;
          sprintf(buff, "%3d.%d",zb,zb2);
          setcursor(2,12);
          dtext(buff); 
          send=1;   
        }
        
        sprintf(buff, "%3d.%d",zb,zb2);
        setcursor(2,12);
        dtext(buff);
        freq=zb*10+zb2;

        if(send==1){
          send_freq(freq);
          send = 4097;
        
        }
        send--;
      }
      
      /* Pol.2 - automaticke ladeni */
      if(pol_menu==2){
        setcursor(2,6);
        switch(aut_rezim){
          case 0:{
          dtext("Lo");
          break;
          }
          case 1:{
          dtext("Me");
          break;
          }
          case 2:{
          dtext("Hi");
          break;
          }
        }
        
        setcursor(2,9);
        switch(aut_rezim2){
          case 0:{
          dtext("DO");
          break;
          }
          case 1:{
          dtext("UP");
          break;
          }
        }
        
        setcursor(2,11);
        get_freq=read_freq();
        zb=get_freq/10;
        zb2=get_freq%10;
        sprintf(buff, "%3d.%d",zb,zb2);
        dtext(buff);
        pockej();
        
        if(PTAD_PTAD5==0){
          pockej();
          aut_rezim++;
          if(aut_rezim==3){
            aut_rezim=0;
          }
        }
        
        if(PTAD_PTAD6==0){
          pockej();
          aut_rezim2++;
          if(aut_rezim2==2){
            aut_rezim2=0;
          }
        }
        
        if(PTAD_PTAD7==0){
          pockej();
          auto_search(aut_rezim,aut_rezim2);
        }
        
        send=1;
      }
      
      /* Pol.3 - pamet radii */
      if(pol_menu==3){
        if(PTAD_PTAD5==0){
          pockej();
          z++;
          if(z>=5){
            z=0;
          }
          send=1;
        }
        
        zb=pamet[z]/10;
        zb2=pamet[z]%10;
        z++;
        sprintf(buff, "%d.%3d.%d FM", z,zb,zb2);
        setcursor(2,5);
        dtext(buff);
              
        while(PTAD_PTAD6==0){
          ATD1SC = 0;
          while(ATD1SC_CCF!=1) __RESET_WATCHDOG();
          zb=(21*ATD1R/1022)+87;
          sprintf(buff, "%d.%3d.%d FM", z,zb,zb2);
          setcursor(2,5);
          dtext(buff);
          send=1;     
        }
        
         while(PTAD_PTAD7==0){
          ATD1SC = 0;
          while(ATD1SC_CCF!=1) __RESET_WATCHDOG();
          zb2=9*ATD1R/1022;
          sprintf(buff, "%d.%3d.%d FM", z,zb,zb2);
          setcursor(2,5);
          dtext(buff); 
          send=1;   
        }
        z--;
        pamet[z]=zb*10+zb2;
        
        if(send==1){
           send_freq(pamet[z]);
           send=4096;
        }
        
        send--;
        
      }
      
      /* Pol.4 - moznost mute/unmute */
      if(pol_menu==4){
        if(PTAD_PTAD5==0){
          pockej();
          mute_celk=1;
        }
        if(PTAD_PTAD6==0){
          pockej();
          mute_celk=0;;
        }        
        mute(mute_celk);
        
      }
      
      /* Pol.5 - moznost mute/unmute leveho a praveho kanalu */
      if(pol_menu==5){
        if(PTAD_PTAD5==0){
          if(mute_L==0){
            mute_L=1;
          } else {
              mute_L=0;
            }
          muteL(mute_L);
        }
        
        if(PTAD_PTAD6==0){
          if(mute_P==0){
            mute_P=1;
          } else {
              mute_P=0;
            }
          muteP(mute_P);
        }
      }
      
      /* Pol.6 - prepinani mono/stereo a moznost standby modu */
      if(pol_menu==6){
        setcursor(1,1);
        switch(audio){
          case 0:{
            dtext("Stereo");
            break;
          }
          case 1:{
            dtext("Mono");
            break;
          } 
         }
         
         setcursor(2,13);
         switch(stdby){
          case 0:{
            dtext("OFF");
          break;
          }
          case 1:{
            dtext("ON");
          break;
          }
         }
         
         if(PTAD_PTAD5==0){
            pockej();
            if(audio==1){
              audio=0;
            } else{
                audio=1;
              }
            mono_stereo(audio);
         }
         
         if(PTAD_PTAD6==0){
              pockej();
              if(stdby==1){
                stdby=0;  
              } else{
                  stdby=1;
                }
              standby(stdby);
         }
          
        }
        
        /* Pol.7 - zapinani a vypinani regulace sumu na vystupu, ovlivnuje pouze pro stereo rezim */
        if(pol_menu==7){
          setcursor(2,7);
          switch(snc){
            case 0: {
            sprintf(buff, "OFF");
            dtext(buff);
            if(PTAD_PTAD5==0){
            pockej();
            snc=1;
            stereo_noise(snc);
            }
            break;
            }
            case 1: {
            sprintf(buff, "ON");
            dtext(buff);
            if(PTAD_PTAD5==0){
            pockej();
            snc=0;
            stereo_noise(snc);
            }
            break;
            }
          }
        
        }
    
      pockej();
      
      kontrola=rc5_read(&togglebit,&databit);       // overeni zda prenos dat probehl spravne, tedy kontrola zustane 1
      if(kontrola==1){
         if(((temptoggle != togglebit) || (tempdata != databit))){
            temptoggle = togglebit;
            tempdata = databit;
            if(databit == 12){
                pol_menu=6;
                if(stdby==1){
                  stdby=0;  
                } else{
                    stdby=1;
                  }
                standby(stdby);
            }
            
            if(databit == 13){
                pol_menu=4;
                if(mute_celk==1){
                  mute_celk=0;
                } else{
                    mute_celk=1;
                  }
                mute(mute_celk);
            }
            
            if(databit == 32){
                pol_menu=3;
                if(z<4){
                  z++;
                }
                send=1;
            }
            
            if(databit == 33){
                pol_menu=3;
                if(z>0){
                  z--;
                }
                send=1;
            }
            
            if(databit == 17){
                pol_menu=2;
                aut_rezim=2;
                aut_rezim2=0;
                auto_search(aut_rezim,aut_rezim2);
            }
            
            if(databit == 16){
                pol_menu=2;
                aut_rezim=2;
                aut_rezim2=1;
                auto_search(aut_rezim,aut_rezim2);   
            }
            
            if((databit > 0) & (databit < 6) & (pol_menu == 2)){
                switch(databit){
                  case 1:{
                  pamet[0]=get_freq;
                  break;
                  }
                  case 2:{
                  pamet[1]=get_freq;
                  break;
                  }
                  case 3:{
                  pamet[2]=get_freq;
                  break;
                  }
                  case 4:{
                  pamet[3]=get_freq;
                  break;
                  }
                  case 5:{
                  pamet[4]=get_freq;
                  break;
                  }
                }
            }
         
         }
         
      }
      __RESET_WATCHDOG();
      
  }

  
  /*
  for(;;) {
    __RESET_WATCHDOG();  feeds the dog 
  //}  loop forever 
   please make sure that you never leave main */
  
}

/* funkce na vypis polozek menu podle vstupniho parametru */
void menu(int i){                                         
  char radek_1[20],radek_2[20];
     switch (i){
      case 0:{
      dcls();
      sprintf(radek_1, "FM radio modul");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, "Posun: SW1");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 1:{
      dcls();
      sprintf(radek_1, "Man. ladeni");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, "SW2/SW3+Rp");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 2:{
      dcls();
      sprintf(radek_1, "Autom. ladeni");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, "Mode");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 3:{
      dcls();
      sprintf(radek_1, "Pamet stanic");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, "SW2");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 4:{
      dcls();
      sprintf(radek_1, "Mute/Unmute");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, "SW2/SW3");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 5:{
      dcls();
      sprintf(radek_1, "Ztlumeni L/P");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, "SW2/SW3");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 6:{
      dcls();
      sprintf(radek_1, "        Standby");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, " SW2    SW3");
      setcursor(2,1);
      dtext(radek_2);
      break;
      }
      case 7:{
      dcls();
      sprintf(radek_1, "Stereo noise");
      setcursor(1,1);
      dtext(radek_1);
      sprintf(radek_2, " SW2");
      setcursor(2,1);
      dtext(radek_2);
      }
     
     }
     
}

/* jednoducha funkce pro "pockani" nekolik milisekund */
void pockej(void){             
    unsigned long i;
    for(i=0;i<10000;i++) __RESET_WATCHDOG();
}

/* obsluha preruseni po zmacknuti tlacitka SW1 */
interrupt void kbi_int(void){  
   pockej();
   if(pol_menu==7){
    pol_menu=0;
   } else {
      pol_menu++;
    }
    
    KBI1SC_KBACK = 1;

}
