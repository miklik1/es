/*-------------------------------------------------------------------------------------------------------------*/
/*------------------------------------ RC5 interupty + nastaveni RC5 ------------------------------------------*/
                          
interrupt void tpm2ch0_int(void);                  //obsluha cteni dat podle RC-5 protokolu
void (*const obs)(void) @0xFFEC = tpm2ch0_int;

interrupt void timer_int(void);                    //obsluha casovace
void (*const obs2)(void) @0xFFE2 = timer_int;

//RC5
#define TOLERATION_NEG 200 
#define TOLERATION_POS 200
#define ei_irda_fall  TPM2C0SC &= 0b11111011 
#define ei_irda_any  TPM2C0SC |= 0b00001100 
#define ei_irda_enable TPM2C0SC |= 0b01000000     //zapne input capture preruseni
#define ei_irda_disable TPM2C0SC &= 0b10111111    //vypne input capture preruseni
#define tcnt_temp TPM2CNT   
#define timer2_clear TPM2CNT = 0                  //vynuluje casovac
#define toie_enable TPM2SC |= 0b01000000
#define toie_disable TPM2SC &= 0b00111111
#define tof_clear TPM2SC &= 0x7F
#define irda_pin PTDD_PTDD3^0x01                  //negovan� hodnota pinu = log uroven RC5  

#include "derivative.h"                           /* include peripheral declarations */
#include "math.h"

char buffer[5];                                   /* globalni pole bajtu pro zapis do TEA5767 */
char read[5];                                     /* globalni pole bajtu pro cteni z TEA5767 */
unsigned char bit_counter = 0, temp_toggle = 0, temp_data = 0;
int kontrola = 0;
unsigned char rc5_toggle = 0, rc5_data = 0;
unsigned short rc_period = 0,  timer_stack = 0;


/*-------------------------------------------------------------------------------------------------------------*/
/*-------------------------------------- init mikropocitace ---------------------------------------------------*/

void ICG_init(void){
 ICGC1 = 0x78;
 ICGC2 = 0x30;
 while(ICGS1_LOCK==0){
 __RESET_WATCHDOG();
 }
}


/*------------------------------------------------------------------------------------------------------------*/
/*---------------------------- Funkce pro komunikaci s TEA5767 -----------------------------------------------*/

  /* funkce init ktera inicializuje I2C komunikaci a nastavi pocatecni hodnotu pole*/
  void Init_I2C (void){  
    unsigned int i;
    IIC1C_IICEN = 1; // Enable I2C;
    IIC1C_TXAK = 1;  // not generate ACK by master after transfer;
    IIC1C_MST = 0;   // Slave mode actually;
    IIC1F = 0x99;    // Set speed 
    IIC1S_SRW = 0;   // R/W bit = 0;
    buffer[0]=  0b00101011;
    buffer[1]=  0b11010000;
    buffer[2]=  0b10110000;
    buffer[3]=  0b00010110;
    buffer[4] = 0b00000000;
    for(i=0;i<30000;i++)__RESET_WATCHDOG(); 
  }

  /* funkce pro poslani 5 bytu do TEA5767 */
  void IIC_write_block(byte addr, byte *data){ 
    unsigned int i;
    IIC1C_TXAK = 0;            // RX/TX = 1; MS/SL = 1; TXAK = 0;
    IIC1C |= 0x30;             // And generate START condition;

    //-------start of transmit first byte to IIC bus-----
    IIC1D = addr;                            // Address the slave and set up for master transmit;
    while (!IIC1S_IICIF)__RESET_WATCHDOG();  // wait until IBIF;
    IIC1S_IICIF=1;                           // clear the interrupt event flag;
    while(IIC1S_RXAK)__RESET_WATCHDOG();     // check for RXAK;
    //-----Slave ACK occurred------------
    for(i=0;i<5;i++)
    {
    IIC1D = data[i];
    while (!IIC1S_IICIF)__RESET_WATCHDOG();  // wait until IBIF;
    IIC1S_IICIF=1;                           // clear the interrupt event flag;
    while(IIC1S_RXAK)__RESET_WATCHDOG();     // check for RXAK;
    }
    //-----Slave ACK occurred------------
    IIC1S_IICIF=1;                           // clear the interrupt event flag;
    IIC1C_MST = 0;                           // generate STOP condition;
    for(i=0;i<1000;i++)__RESET_WATCHDOG(); 
  }
  
  /* funkce pro cteni bytu z TEA5767 */
  void IIC_read_byte(byte addr, byte *data){  
    unsigned int i;
    int x;
    byte dummy;
    IIC1C_TXAK = 0;            // RX/TX = 1; MS/SL = 1; TXAK = 0;
    IIC1C |= 0x30;             // And generate START condition;
    
    //-----Start of transmit first byte to IIC bus-----
    IIC1D = 0xC0;                            // Address the slave and set up for master transmit;
    while (!IIC1S_IICIF)__RESET_WATCHDOG();  // wait until IBIF;
    IIC1S_IICIF=1;                           // clear the interrupt event flag;
    while(IIC1S_RXAK)__RESET_WATCHDOG();     // check for RXAK;
    //-----Slave ACK occurred------------
    IIC1C_RSTA = 1;                          // set up for repeated start
    IIC1D = addr;                            // slave adress read
    while(!IIC1S_IICIF)__RESET_WATCHDOG();   // wait until IBIF
    IIC1S_IICIF=1;                           // clear the interrupt event flag;
    while(IIC1S_RXAK)__RESET_WATCHDOG();     // check for RXAK;
    IIC1C_TX = 0;                            // set up to receive;
    dummy = IIC1D;                           // dummy read
    for(x=0;x<4;x++){
        while (!IIC1S_IICIF)__RESET_WATCHDOG();  // wait until IBIF;
        IIC1S_IICIF=1;                           // clear the interrupt event flag;
        data[x]=IIC1D;
    }
    IIC1C_TXAK = 1;                          // acknowledge disable;
    while (!IIC1S_IICIF)__RESET_WATCHDOG();  // wait until IBIF;
    IIC1S_IICIF=1;                           // clear the interrupt event flag;
    IIC1C_MST = 0;                           // generate STOP condition;  
    data[4]=IIC1D;                         
    for(i=0;i<1000;i++)__RESET_WATCHDOG();
  }
 
/*----------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------- Uzivatelske funkce ---------------------------------------------------*/
  
  /* funkce pro posladni frekvence do TEA5767, vst hodnota je frekvence*10. 97,8 -> 978 */
  void send_freq(int freq){   
     word freq14bit=0;
     char freqH,freqL;
     if((freq>=700) && (freq<=1080)){
         freq14bit = (4 * (freq * 100000 + 225000)/32768)+1;       //rozlozeni frekvence na dva bajty tzv PLL word (14 bitu)
         freqH = (freq14bit >> 8 );
         freqL = (freq14bit & 0xFF);
         buffer[0] = 0x00;
         buffer[0] = freqH;
         buffer[1] = freqL;
         IIC_write_block(0xC0,&buffer[0]); 
     }
  }
  
  /* funkce pro ztlumeni audio vystupu, vst parametr 1 = ON, 0 = OFF */
  void mute(int mode){
     int freq;
     
     freq = read_freq();
     send_freq(freq);
       
     switch(mode){
      case 0:{
      buffer[0] = buffer[0] & 0x7F;
      break;
      }
      case 1:{
      buffer[0] = buffer[0] | 0x80;
      break;
      }
      default:{
      buffer[0] = buffer[0] & 0x7F;
      break;
      }
     }
     IIC_write_block(0xC0,&buffer[0]);
  }
  
  /* funkce pro ztlumeni leveho kanalu, vst parametr 1 = ON, 0 = OFF */ 
  void muteP(int mode){  
     switch(mode){
      case 0:{
      buffer[2] = buffer[2] & 0xFD;
      break;
      }
      case 1:{
      buffer[2] = buffer[2] | 0x02;
      break;
      }
      default:{
      buffer[2] = buffer[2] & 0xFD;
      break;
      }
     }
     IIC_write_block(0xC0,&buffer[0]);
  }
  
  /* funkce pro ztlumeni praveho kanalu, vst parametr 1 = ON, 0 = OFF */
  void muteL(int mode){  
     switch(mode){
      case 0:{
      buffer[2] = buffer[2] & 0xFB;
      break;
      }
      case 1:{
      buffer[2] = buffer[2] | 0x04;
      break;
      }
      default:{
      buffer[2] = buffer[2] & 0xFB;
      break;
      }
     }
     IIC_write_block(0xC0,&buffer[0]);
  }
  
  /* funkce pro automaticke hledani stanice */
  /* prvni parametr 0,1,2 a znaci silu vyst signalu */
  /* druhy parametr 1 pro hledani nahoru a 0 pro hledani dolu */
  void auto_search(int mode, int up_down){   
      int frequency;                         
      word freq14bit=0;                      
      char freqH,freqL;
      
      switch(mode){
        case 0:{
        buffer[2]=  0b10110000;
        break;
        }
        case 1:{
        buffer[2]=  0b11010000;
        break;
        }
        case 2:{
        buffer[2]=  0b11110000;
        break;
        }
        default: {
        buffer[2]=  0b11110000;
        break;
        }
      }
      
      frequency=read_freq();
      
      switch(up_down){
        case 0:{
        frequency=frequency-2;
        buffer[2] = buffer[2] & 0x7F;  
        break;
        }
        case 1:{
        frequency=frequency+2;
        buffer[2] = buffer[2] | 0x80;  
        break;
        }
        default:{
        buffer[2] = buffer[2] | 0x80;
        break;
        }
      }

      freq14bit = (4 * (frequency * 100000 + 225000)/32768)+1;
      freqH = (freq14bit >> 8 );
      freqL = (freq14bit & 0xFF);
      
      buffer[0] = 0b00000000;
      buffer[0] = freqH;
      buffer[0] = buffer[0] | 0x40;
      buffer[1] = freqL;
      

      IIC_write_block(0xC0, &buffer[0]); 
  }
  
  /* funkce pro standy mod, vst parametr 1 = ON, 0 = OFF */
  void standby(int mode){    
      switch(mode){
        case 0:{
        buffer[3] = buffer[3] & 0xBF;
        break;
        }
        case 1:{
        buffer[3] = buffer[3] | 0x40;
        break;
        }
        default:{
        buffer[3] = buffer[3] & 0xBF;
        break;
        }
      }
      IIC_write_block(0xC0, &buffer[0]);
  }
  
  /* funkce pro filtraci vystupu pro stereo audio vystup, vst parametr 1 = ON, 0 = OFF */
  void stereo_noise(int mode){    
      switch(mode){
        case 0:{
        buffer[3] = buffer[3] & 0xFD;       
        break;
        }
        case 1:{
        buffer[3] = buffer[3] | 0x02;
        buffer[2] = buffer[2] & 0xFB;
        break;
        }  
        default: {
        buffer[3] = buffer[3] & 0xFD;
        break;
        }
       }
       IIC_write_block(0xC0, &buffer[0]);
  }
  
  /* funkce pro prepinani mono/stereo, vst parametr 1 = mono, 0 = stereo */
  void mono_stereo(int mode){ 
      switch(mode){
        case 0:{
        buffer[2] = buffer[2] & 0xFB;       
        break;
        }
        case 1:{
        buffer[2] = buffer[2] | 0x08;
        buffer[3] = buffer[3] & 0xFD;
        break;
        } 
        default:{
        buffer[2] = buffer[2] & 0xFB;
        break;
        }
       }
       IIC_write_block(0xC0, &buffer[0]);
  }
 
  /* funkce pro precteni frekvence z TEA5767 */ 
  int read_freq(void){   
    int i=0;
    int frequency=0;
      IIC_read_byte(0xC1, &read[0]);
      
      frequency=(((((read[0]&0x3F)<<8)+read[1])+1)*32768/4-225000)/100000;
      return frequency;
  }

  
  /*------------------------------------------------------------------------------------------------------*/
  /*---------------------------------------------- RC5 ---------------------------------------------------*/
  
 
/* funkce na inicializaci RC5 */
void Init_RC5(void){

      //Inicializace TPM2CH0 pinu                         
     PTDDD_PTDDD3=0;     
     PTDPE_PTDPE3=1;        
  
     TPM2MOD = 37500;    //preru�en� - 30 ms
                       
                       
     //TPM2C0SC: CH0F=0,CH2IE=1,MS0B=0,MS0A=0,ELS1B=1,ELS0A=0
     TPM2C0SC = 0b01001000;

     // TPM2SC: TOF=0,TOIE=0,CPWMS=0,CLKSB=0,CLKSA=1,PS2=1,PS1=0,PS0=0 
     TPM2SC = 0b00001100;      
     kontrola = 0;  

} 

/* funkce, ktera vraci hodnoty toggle a dat */
int rc5_read(char *toggle, char *data){
    
    int check;
    check = kontrola;
    *toggle = rc5_toggle;
    *data = rc5_data;

    return(check); 
    
}

/* obsluha preruseni pro timer_int */
interrupt void timer_int(void)  {
  
  TPM2SC &= 0x7F;  	// nuluj priznak preruseni 
 
  toie_disable;
   
  temp_toggle = 0;
  temp_data = 0;
  
  ei_irda_fall;
  bit_counter = 0;
   
  
}


/* obsluha preruseni pro prijati signalu na pinu z IR prijimace, kontrola prijatych bitu a ulozeni dat do promennych */
interrupt void tpm2ch0_int(void){
    
  TPM2C0SC_CH0F = 0;    // ACK channel interrupt 

  if(bit_counter == 0){                     //prvn� start_bit                           
          timer2_clear;
          tof_clear;
          bit_counter++;
          toie_enable;             
                           
  } else if(bit_counter == 1){            //druh� start_bit
          rc_period = tcnt_temp;
          
          timer_stack = tcnt_temp;  
          
          ei_irda_any;             
          bit_counter++;                             
         
  } else if (((tcnt_temp-timer_stack)>(rc_period - TOLERATION_NEG)) && ((tcnt_temp-timer_stack)<(rc_period + TOLERATION_POS))) {   //overeni hrany zda je v toleranci
          
          timer_stack = tcnt_temp;

          
          if(bit_counter == 2){ 
                  temp_toggle = irda_pin;                      //ulozeni toggle bitu
                                             
          } else if((bit_counter > 2)&&(bit_counter < 8)){     //adresove bity jsou vynechany

                                                 
          } else if((bit_counter > 7)&&(bit_counter < 14)){    //ulozeni datovych bitu
                  temp_data <<= 1;
                  temp_data = temp_data + irda_pin;
                       
                  //posledn� bit
                  if(bit_counter == 13){
                        toie_disable;
                  
                        bit_counter = 255;

                        //ukl�d�n� dat                               
                        rc5_toggle = temp_toggle;
                        rc5_data = temp_data;       
                  
                        //nulov�n� dat
                        temp_toggle = 0;
                        temp_data = 0;  
                        
                        ei_irda_fall; 
                        kontrola = 1;                                               
                  }
          } 
	bit_counter++;	   
  } 
}



  