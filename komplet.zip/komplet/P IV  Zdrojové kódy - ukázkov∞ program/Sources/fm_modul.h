// --------------------------------------------------------------------------------
// Hlavickovy soubor pro ovladac modulu FM radio
// --------------------------------------------------------------------------------

void ICG_init(void);
void Init_I2C (void);
void IIC_write_block(byte addr, byte *data);
void IIC_read_byte(byte addr, byte data);
void send_freq(int freq);
void mute(int mode);
void muteP(int mode);
void muteL(int mode);
void auto_search(int mode, int up_down);  
void standby(int mode);
void stereo_noise(int mode);
void mono_stereo(int mode);
int read_freq(void);
int rc5_read(char *toggle, char *data);
void Init_RC5(void);


