import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ScrollingModule } from '@angular/cdk/scrolling';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.page.html',
  styleUrls: ['./gallery.page.scss'],
})
export class GalleryPage implements OnInit {
  imageList = [];
  page = 0;
  maximumPages = 3;

  constructor(private http: HttpClient) {
    this.loadImages();
  }

  ngOnInit() {
  }

  loadImages() {
    this.http.get(`https://randomuser.me/api/?results=100&page=${this.page}`)
    .subscribe(res => {
      this.imageList = res['results'];
      console.log (res);
    });
  }

  separateLetter(record, recordIndex, records) {
    if (recordIndex === 0) {
      return record.name.last[0].toUpperCase();
    }

    let firstPrev = records[recordIndex - 1].name.last[0];
    let firstCurrent = record.name.last[0];

    if (firstPrev !== firstCurrent) {
      return firstCurrent.toUpperCase();
    }
  }

  // loadImages(event?) {
  //   this.http.get(`https://randomuser.me/api/?results=20&page=${this.page}`)
  //    .subscribe(res => {
  //     console.log(res);
  //     this.imageList = this.imageList.concat(res['results']);

  //     if (event) {
  //       event.target.complete();
  //     }
  //   });
  // }

  // loadMore() {
  //   console.log(event);
  //   this.page++;
  //   this.loadImages(event);

  //   // if (this.page === this.maximumPages) {
  //   //   event.target. = true;
  //   // }
  // }
}
